list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 5, 6, 7]

merged = list1 + list2
result = []

for i in merged:
    if i not in result:
        result.append(i)

print("Merged list:", result)
