from library.book import add_book
from library.member import add_member

while True:
    print("\n1. Add Book")
    print("2. Add Member")
    print("3. Exit")

    ch = input("Enter choice: ")

    if ch == "1":
        add_book()
    elif ch == "2":
        add_member()
    elif ch == "3":
        break
    else:
        print("Invalid choice")
