def add_member():
    import csv

    with open("records.csv", "a", newline="") as f:
        w = csv.writer(f)
        member = input("Enter member name: ")
        w.writerow(["Member", member])

    print("Member added!")
