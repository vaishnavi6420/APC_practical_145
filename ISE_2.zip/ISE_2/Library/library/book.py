def add_book():
    import csv

    with open("records.csv", "a", newline="") as f:
        w = csv.writer(f)
        book = input("Enter book name: ")
        w.writerow(["Book", book])

    print("Book added!")
